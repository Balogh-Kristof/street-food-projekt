
function openNav() {
    document.getElementById("navigaciomenu").style.width = "300px";
  }
  

  function closeNav() {
    document.getElementById("navigaciomenu").style.width = "0";
  }